<?php
	echo 'GLOB'.PHP_EOL;
	chdir( '.' );
	$arquivos = glob("{*.php,*.jpg}", GLOB_BRACE);
	foreach($arquivos as $img) echo $img.PHP_EOL;
	echo PHP_EOL;

	$types = array( 'php', 'jpg' );
	
    echo 'DIR FUNCTIONS'.PHP_EOL;
	if ( $handle = opendir('.') ) {
	    while ( $entry = readdir( $handle ) ) {
	    	$ext = strtolower( pathinfo( $entry, PATHINFO_EXTENSION) );
			if( in_array( $ext, $types ) ) echo $entry.PHP_EOL;
	    }
	    closedir($handle);
	}    
	echo PHP_EOL;

    echo 'DIRECTORY ITERATOR'.PHP_EOL;
	$path = '.';
	$dir = new DirectoryIterator($path);
	foreach ($dir as $fileInfo) {
    	$ext = strtolower( $fileInfo->getExtension() );
	    if( in_array( $ext, $types ) ) echo $fileInfo->getFilename().PHP_EOL;
	}    
