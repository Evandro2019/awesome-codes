/*
		leia --- COMENT�RIOS SOBRE AS VARI�VEIS DESTA P�GINA !!!
	foto.numMax    - � o n�mero de fotos na pasta
	foto.numAtual   - a contagem das fotos come�a em 1
	foto.asomar      - se o n�mero real da primeira foto n�o come�a em 1, colocar o valor que deve ser somado pra ele ser achado
				 exemplo: se a primeira foto se chama 'foto029.jpg', o n�mero real dela � 29, portanto o valor de asomar deve ser 28
	foto.endereco   - aqui vc coloca o endere�o da foto at� o n�mero real dela.
				 veja os exemplos abaixo, e depois visualize a p�gina e click com o botao direito > propriedades
				 para ver como fica o endere�o da foto
	foto.numReais  - se as fotos n�o seguem uma ordem tipo 1, 2, 3, 4... ent�o vc dever� expecificar qual � a ordem q elas seguem
				-> o que s�o os 'n�meros reais das fotos'?
				-> resposta: se a foto se chama 'foto029.jpg', o n�mero real dela � 29

		--- o coment�rio atual pode ser deletado para limpar o c�digo ---
		--- por�m, cuidado para n�o esquecer do que se tratam as vari�veis!!! ---
		--- caso ache melhor, deixe os coment�rios a�, que n�o ter� problema se vc esquecer ;) ---
*/


foto = new Object()

function getDadosFoto(grupo)
{
	foto.numMax = 0;
	foto.numAtual = 1;
	foto.asomar = 0;
	foto.autorNome = "";
	foto.autorEmail = "";
	foto.endereco = "";
	foto.extensao = "";
	foto.numReais = new Array();
	

switch(grupo)
{
case 1:default:
	foto.numMax = 8;
	foto.autorNome = "leone silva boaventura";
	foto.autorEmail = "leone@fdvmg.edu.br";
	foto.endereco = "http://br.geocities.com/fotossafdv/images/PICT000";
	foto.extensao = ".jpg";
	break;
case 2:
	foto.numMax = 81;
	foto.asomar = 55; //o n�mero real da primeira foto � 56
	foto.autorNome = "samuel alves";
	foto.autorEmail = "samuel.silveira.alves@gmail.com";
	foto.endereco = "http://br.geocities.com/fotossafdv/images4/imagem_0";
	foto.extensao = ".jpg";
	break;
case 3:
	foto.numReais = new Array(3,6,7,10,11,12,8,9,14,13,4,16,17,19,20,21,22,23,18);
	foto.numMax = foto.numReais.length;
	foto.autorNome = "marcos roberto lopes";
	foto.autorEmail = "marcosrl@ufv.br";
	foto.endereco = "http://br.geocities.com/fotossafdv2/images7/STA600";
	foto.extensao = ".jpg";
	break;
}
return foto;
}