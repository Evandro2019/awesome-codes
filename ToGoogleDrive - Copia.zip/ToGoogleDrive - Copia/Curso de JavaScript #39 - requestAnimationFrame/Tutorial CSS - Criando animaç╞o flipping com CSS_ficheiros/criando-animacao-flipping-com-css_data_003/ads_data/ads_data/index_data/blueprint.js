window.blueprint = {
	"width": 160,
	"height": 600,
	"images": [
		"logo_vimeo.png",
		"txt_1.png",
		"txt_2.png",
		"txt_3.png",
		"cta_1.png",
		"ctaHover_1.png",
		"bling.png",
		"shine.png",
		"overlay.png"
	],
	"elements": {
		"stage": {
			"parent": "banner",
			"id": "stage",
			"retina": false,
			"left": 0,
			"top": 0,
			"safeArea": 0,
			"lineHeight": 0,
			"width": 160,
			"height": 600
		},
		"bg": {
			"parent": "banner",
			"id": "bg",
			"retina": false,
			"left": 0,
			"top": 0,
			"safeArea": 0,
			"lineHeight": 0,
			"width": 160,
			"height": 600
		},
		"logo_vimeo": {
			"parent": "banner",
			"id": "logo_vimeo",
			"retina": true,
			"left": 16,
			"top": 42,
			"safeArea": 0,
			"lineHeight": 0,
			"backgroundImage": "logo_vimeo.png",
			"width": 92,
			"height": 27
		},
		"txt_1": {
			"parent": "banner",
			"id": "txt_1",
			"retina": true,
			"left": -9,
			"top": 99,
			"safeArea": 25,
			"lineHeight": 25.380000000000003,
			"backgroundImage": "txt_1.png",
			"width": 177,
			"height": 121
		},
		"txt_2": {
			"parent": "banner",
			"id": "txt_2",
			"retina": true,
			"left": -9,
			"top": 98.72,
			"safeArea": 25,
			"lineHeight": 23.005000000000003,
			"backgroundImage": "txt_2.png",
			"width": 178,
			"height": 91
		},
		"txt_3": {
			"parent": "banner",
			"id": "txt_3",
			"retina": true,
			"left": 1,
			"top": 160,
			"safeArea": 15,
			"lineHeight": 15.600000000000001,
			"backgroundImage": "txt_3.png",
			"width": 147,
			"height": 43
		},
		"cta": {
			"parent": "banner",
			"id": "cta",
			"retina": true,
			"left": 16,
			"top": 249.75,
			"safeArea": 0,
			"lineHeight": 15.600000000000001
		},
		"cta_1": {
			"parent": "cta",
			"id": "cta_1",
			"retina": true,
			"backgroundImage": "cta_1.png"
		},
		"ctaHover": {
			"parent": "banner",
			"id": "ctaHover",
			"retina": true,
			"left": 90,
			"top": 123.75,
			"safeArea": 0,
			"lineHeight": 15.600000000000001
		},
		"ctaHover_1": {
			"parent": "ctaHover",
			"id": "ctaHover_1",
			"retina": true,
			"backgroundImage": "ctaHover_1.png"
		},
		"bling": {
			"parent": "banner",
			"id": "bling",
			"retina": true,
			"left": 93,
			"top": 232,
			"safeArea": 0,
			"lineHeight": 0,
			"backgroundImage": "bling.png",
			"width": 32,
			"height": 33
		},
		"shine": {
			"parent": "banner",
			"id": "shine",
			"retina": true,
			"left": -251,
			"top": -239,
			"safeArea": 0,
			"lineHeight": 0,
			"backgroundImage": "shine.png",
			"width": 661,
			"height": 1068
		},
		"overlay": {
			"parent": "banner",
			"id": "overlay",
			"retina": true,
			"left": 0,
			"top": 0,
			"safeArea": 0,
			"lineHeight": 0,
			"backgroundImage": "overlay.png",
			"width": 160,
			"height": 600
		},
		"top": {
			"parent": "banner",
			"id": "top",
			"retina": false,
			"left": 0,
			"top": -10,
			"safeArea": 0,
			"lineHeight": 0,
			"width": 160,
			"height": 10
		},
		"bottom": {
			"parent": "banner",
			"id": "bottom",
			"retina": false,
			"left": 0,
			"top": 600,
			"safeArea": 0,
			"lineHeight": 0,
			"width": 160,
			"height": 10
		},
		"left": {
			"parent": "banner",
			"id": "left",
			"retina": false,
			"left": -10,
			"top": 0,
			"safeArea": 0,
			"lineHeight": 0,
			"width": 10,
			"height": 600
		},
		"right": {
			"parent": "banner",
			"id": "right",
			"retina": false,
			"left": 160,
			"top": 0,
			"safeArea": 0,
			"lineHeight": 0,
			"width": 10,
			"height": 600
		}
	},
	"settings": {
		"filename": "Q3-2019_EN_mid-funnel_videopro_high-quality_1_learn-more_160x600_HTML5",
		"market": "EN",
		"campaign": "Q3-2019",
		"funnel": "mid-funnel",
		"segment": "videopro",
		"feature": "high-quality",
		"copyVariation": "1",
		"size": "160x600",
		"marketIndex": "1",
		"id": "videoprohigh-quality1",
		"copy": {
			"copy1": "Engineered to drop jaws.",
			"copy2": "High-Quality Player.",
			"copy3": "A Vimeo Feature",
			"copy4": "Learn More",
			"copy5": ""
		},
		"fileType": "jpg",
		"fallback": true,
		"HtmlfileType": "html",
		"backgroundColor": "#e59fb9"
	}
};