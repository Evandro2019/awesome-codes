const express = require("express");
const app = express();

app.get("/", function(req, res){
	res.send("Bem vindos ao Baba´s nodemon that´s the Highest on High!");
	//res.send(req.params);
	//res.send(req.params.nome);
	//res.send("Hello " + req.params.nome);
	//...preste atenção! Você só consegue enviar o send uma vez
	//res.send("<h1>Hello " + req.params.nome + "</h1>"+"<h2>Seu cargo eh: " + req.params.cargo + "</h2>"+"<h3>Sua cor favorita eh:  " + req.params.cor + "</h3>");
	//res.sendfile(__dirname + "/html/index.html");

});

app.get("/index", function(req, res){
	res.sendfile(__dirname + "/html/index.html")

});

app.get("/sobre", function(req, res){
	res.sendfile(__dirname + "/html/sobre.html");
});


app.listen(8081, function(){
	console.log("servidor rodando na url http:localhost:8081");

});