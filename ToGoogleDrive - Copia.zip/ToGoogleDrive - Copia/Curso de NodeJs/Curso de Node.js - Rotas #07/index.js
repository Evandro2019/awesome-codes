const express = require("express");
const app = express();

app.get("/", function(req, res){
	res.send("Welcome to the Jungle!");

});


app.get("/shiva", function(req, res){
	res.send("Patit Pavan Beloved Almighty Father, Welcome to the Jungle!");

});


app.get("/brahma", function(req, res){
	res.send("My sweet friend, number one pavitrata sample, Welcome to the Jungle!");

});
app.listen(8081, function(){
	console.log("servidor rodando na url http:localhost:8081")


});
