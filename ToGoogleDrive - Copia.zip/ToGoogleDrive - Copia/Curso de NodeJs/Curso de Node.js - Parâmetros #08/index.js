const express = require("express");
const app = express();

app.get("/ola/:nome/:cargo/:cor", function(req, res){
	//res.send("Welcome to the Jungle!");
	//res.send(req.params);
	//res.send(req.params.nome);
	//res.send("Hello " + req.params.nome);
	//...preste atenção! Você só consegue enviar o send uma vez
	res.send("<h1>Hello " + req.params.nome + "</h1>"+"<h2>Seu cargo eh: " + req.params.cargo + "</h2>"+"<h3>Sua cor favorita eh:  " + req.params.cor + "</h3>");
	
});


app.listen(8081, function(){
	console.log("servidor rodando na url http:localhost:8081");


});