CREATE TABLE usuarios(
	nome VARCHAR(50),
	email VARCHAR(100),
	idade INT

);

INSERT INTO usuarios(nome, email, idade) VALUES(
"SatGuru Shiv Baba Bolanath",
"shiva@paramdhan.org",
5000



INSERT INTO usuarios(nome, email, idade) VALUES(
"ParamPita Shiva ParamAtma",
"brahma@madhuban.org",
100);


INSERT INTO usuarios(nome, email, idade) VALUES(
"General Hanuman",
"agente@exercitodosmacacos.mil",
100);