var http = require('http');

http.createServer(function(req, res){
	res.end("Hello Baba!ctrl mouseScroll para Zooniar");
}).listen(8081);

console.log("O Servidor rodando! ctrl c  pra fechar...");


